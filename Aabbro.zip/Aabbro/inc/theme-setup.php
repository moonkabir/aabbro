<?php
/**
 * File description
 *
 * @package fooday
 */

if (!defined('ABSPATH')) {
 exit; // Exit if accessed directly.
}
/**
 * Theme Setup.
 */

function aabbro_setup()
{
 add_theme_support('title-tag');
 add_theme_support(
  'post-formats',
  array(
   'aside',
   'audio',
   'gallery',
   'image',
   'link',
   'quote',
   'video',
  )
 );
 add_theme_support('post-thumbnails');
 add_theme_support(
  'html5',
  array(
   'search-form',
   'comment-form',
   'comment-list',
   'gallery',
   'caption',
  )
 );
 add_theme_support('custom-logo');
 add_theme_support('custom-background');
 add_theme_support('customize-selective-refresh-widgets');
 add_theme_support('custom-header');
 add_theme_support('automatic-feed-links');
 add_image_size('post-image', 940, 340);
 if (!isset($content_width)) {
  $content_width = 1140;
 }

 register_nav_menus(array(
  'main-menu' => __('Primary Menu', 'aabbro'),
 ));

}

add_action('after_setup_theme', 'aabbro_setup');