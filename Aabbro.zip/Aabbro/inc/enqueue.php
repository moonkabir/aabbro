<?php
/**
 * File description
 *
 * @package aabbro
 */
if (!defined('ABSPATH')) {
 exit; // Exit if accessed directly.
}
/**
 * Enqueue scripts and styles.
 */
function aabbro_enqueue_scripts()
{
 define("PATH", get_template_directory_uri() . '/assets');
 define("PATHABS", get_template_directory() . '');
//  $the_theme = wp_get_theme();
 //  $theme_version = $the_theme->get('version');
 //  $css_version = $theme_version . '.' . filemtime(PATHABS . 'css/layout.css');
 //  Main style sheet
 // responsive style sheet

 wp_enqueue_style('google-font', 'https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700', null, 1.00, 'all');
 wp_enqueue_style('circular', PATH . '/fonts/circular-std/css/circular-std.css', null, 1.00, 'all');
 wp_enqueue_style('bootstrap', PATH . '/vendor/bootstrap/css/bootstrap.min.css', null, 1.00, 'all');
 wp_enqueue_style('mega-menu', PATH . '/vendor/mega-menu/css/menu.css', null, 1.00, 'all');
 wp_enqueue_style('fontawesome', PATH . '/fonts/font-awesome/css/font-awesome.min.css');
 wp_enqueue_style('owl-carousel', PATH . '/vendor/owl-carousel/owl.carousel.css', null, 1.00, 'all');
 wp_enqueue_style('owl-theme', PATH . '/vendor/owl-carousel/owl-theme.css', null, 1.00, 'all');
 wp_enqueue_style('animate', PATH . '/vendor/owl-carousel/animate.css', null, 1.00, 'all');
 wp_enqueue_style('aos-next', PATH . '/vendor/aos-next/dist/aos.css', null, 1.00, 'all');
 wp_enqueue_style('fancybox', PATH . '/vendor/fancybox/dist/jquery.fancybox.css', null, 1.00, 'all');
 wp_enqueue_style('snazzy-map', PATH . '/vendor/snazzy-map/dist/snazzy-info-window.min.css', null, 1.00, 'all');
 wp_enqueue_style('flat-icon', PATH . '/fonts/icon/font/flaticon.css', null, 1.00, 'all');
 wp_enqueue_style('custom-animation', PATH . '/css/custom-animation.css', null, 1.00, 'all');
 wp_enqueue_style('animated-headline', PATH . '/vendor/animated-headline-master/style.css', null, 1.00, 'all');
 wp_enqueue_style('iziModal-master', PATH . '/vendor/iziModal-master/iziModal.css', null, 1.00, 'all');
 wp_enqueue_style('jquery-ui', PATH . '/vendor/jquery-ui/jequery-ui.min.css', null, 1.00, 'all');
 wp_enqueue_style('selectize', PATH . '/vendor/selectize.js/selectize.css', null, 1.00, 'all');
 wp_enqueue_style('tabs', PATH . '/vendor/tabs/tabs.css', null, 1.00, 'all');
 wp_enqueue_style('framework', PATH . '/css/framework.css', null, 1.00, 'all');
 wp_enqueue_style('custom-style', PATH . '/css/style.css', null, 1.00, 'all');
 wp_enqueue_style('responsive', PATH . '/css/responsive.css', null, 1.00, 'all');
//  wp_enqueue_style('tabs', PATH . '/assets/fonts/gilroy/fonts.css', null, 1.00, 'all');
 //  wp_enqueue_style('animated', PATH . '/vendor/animated-headline-master/style.css', null, 1.00, 'all');
 //  wp_enqueue_style('cuberportfolio', PATH . '/vendor/cuberportfolio/css/cuberportfolio.min.css', null, 1.00, 'all');

 // ===============
 //     scripts
 // ===============

//  wp_enqueue_script('jquery', PATH . '/vendor/jquery.2.2.3.min.js', array('jquery'), 1.00, true);
 //   Popper js -->
 wp_enqueue_script('proper', PATH . '/vendor/popper.js/popper.min.js', array('jquery'), 1.00, true);
//   Bootstrap JS
 wp_enqueue_script('bootstrap', PATH . '/vendor/bootstrap/js/bootstrap.min.js', array('jquery'), 1.00, true);
//   menu
 wp_enqueue_script('custom-js', PATH . '/vendor/mega-menu/assets/js/custom.js', array('jquery'), 1.00, true);
//   AOS js
 wp_enqueue_script('aos-js', PATH . '/vendor/aos-next/dist/aos.js', array('jquery'), 1.00, true);
//   WOW js
 wp_enqueue_script('wow-js', PATH . '/vendor/WOW-master/dist/wow.min.js', array('jquery'), 1.00, true);
//   owl.carousel
 wp_enqueue_script('owl-carousel', PATH . '/vendor/owl-carousel/owl.carousel.min.js', array('jquery'), 1.00, true);
//   apear-js
 wp_enqueue_script('apear-js', PATH . '/vendor/jquery.appear.js', array('jquery'), 1.00, true);
//   counter-js
 wp_enqueue_script('countTo', PATH . '/vendor/jquery.countTo.js', array('jquery'), 1.00, true);
//   Fancybox
 wp_enqueue_script('fancybox-js', PATH . '/vendor/fancybox/dist/jquery.fancybox.min.js', array('jquery'), 1.00, true);
//   Tilt js
 wp_enqueue_script('translate', 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit', array('jquery'), 1.00, true);
 // theme js
 wp_enqueue_script('lang-js', PATH . '/js/lang.js', array('jquery'), 1.00, true);
 wp_enqueue_script('theme-js', PATH . '/js/theme.js', array('jquery'), 1.00, true);
}
add_action('wp_enqueue_scripts', 'aabbro_enqueue_scripts');