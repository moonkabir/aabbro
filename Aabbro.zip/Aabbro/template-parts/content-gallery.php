<div class="item">
    <div class="img-box">
        <!-- <img src="<?php //echo get_template_directory_uri(); ?>/assets/images/portfolio/1.jpg" alt=""> -->
        <?php the_post_thumbnail('post-image', array('class' => 'img img-responsive'));?>
        <div class="hover-content">
            <a href="<?php echo get_template_directory_uri(); ?>/assets/images/portfolio/1.jpg"
                class="icon zoom fancybox" data-fancybox="<?php echo get_template_directory_uri(); ?>/assets/images"
                data-caption="My caption">+</a>
        </div>
    </div>
</div>