<?php
$aabbro_fp = new WP_Query(
    array(
        'meta_key'       => 'testimonial',
        'meta_value'     => '1',
        'posts_per_page' => 3
    )
);

$post_data = array();
while ( $aabbro_fp->have_posts() ) {
    $aabbro_fp->the_post();
    $post_data[] = array(
        "author"=>get_the_author_meta("display_name"),
        "author-designation"=>get_the_author_meta("description"),
        'author_avatar'=>get_avatar_url(get_the_author_meta("ID")),
        'excerpt'=>get_the_excerpt()
    );
}

if ( $aabbro_fp->post_count > 1 ):
    ?>
    <div class="shape-box">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/4.png" alt="">

        <?php
        for($i=1; $i<7;$i++):
            ?>
            <img src="<?php echo esc_url($post_data[$i]['author_avatar']) ?>" alt="" class="people">
        <?php
        endfor;
        ?>

        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-6.svg" alt="" class="shape-one">
    </div>
    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-66.svg" alt="" class="shape-two" data-aos="fade-left">
    <div class="container clearfix">
        <div class="main-content">
            <div class="theme-title-one">
                <div class="upper-title">Testimonials</div>
                <h2 class="main-title">Check what’s our client say about us!</h2>
            </div> <!-- /.theme-title-one -->

            <div class="agn-testimonial-slider">
                <?php
                    for($i=1; $i<3;$i++):
                ?>
                <div class="item">
                    <p> <?php echo esc_html($post_data[$i]['excerpt']) ?></p>
                    <div class="author-info clearfix">
                        <img src="<?php echo esc_url($post_data[$i]['author_avatar']) ?>" alt="" class="author-img">
                        <div class="name-info">
                            <h6 class="name"><?php echo esc_html($post_data[$i]['author']) ?></h6>
                            <span><?php echo esc_html($post_data[$i]['author-designation']) ?></span>
                        </div>
                    </div>
                </div>
                <?php
                    endfor;
                ?>
            </div> <!-- /.agn-testimonial-slider -->
        </div> <!-- /.main-content -->
    </div> <!-- /.container -->
<?php
endif;













