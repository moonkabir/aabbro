<?php

$aabbro_fp = new WP_Query(
    array(
        'meta_key'       => 'featured',
        'meta_value'     => '1',
        'posts_per_page' => 5
    )
);

$post_data = array();
while ( $aabbro_fp->have_posts() ) {
    $aabbro_fp->the_post();
    $categories = get_the_category();
    $post_data[] = array(
        "title" => get_the_title(),
        "permalink"=>get_permalink(),
        "thumbnail"=>get_the_post_thumbnail_url(get_the_ID(),"large"),
        'excerpt'=>get_the_excerpt()
    );
}
//echo wp_trim_words( ($post_data[0]['excerpt']), 15, '...' );
if ( $aabbro_fp->post_count > 1 ):
    ?>
    <div class="row mtm-85">
        <div class="col-lg-4">
            <div class="feature-block-one mt-300 md-mt-50">
                <img src="<?php echo esc_url($post_data[0]['thumbnail']) ?>" alt="" class="img-icon">
                <h5 class="pt-30 pb-25 tran3s title"><?php echo esc_html($post_data[0]['title']) ?></h5>
                <div class="tran3s">
                    <?php echo esc_html(wp_trim_words( ($post_data[0]['excerpt']), 15,'' )) ?>
                </div>
                <a href="<?php echo esc_url($post_data[0]['permalink']) ?>" class="read-more tran3s"><i class="flaticon-next-1"></i></a>
            </div> <!-- /.feature-block-one -->
        </div>
        <div class="col-lg-4 col-md-6">
            <?php
            for($i=1; $i<3;$i++):
                ?>
                <div class="feature-block-one mb-45 mt-85 md-mt-40">
                    <img src="<?php echo esc_url($post_data[$i]['thumbnail']) ?>" alt="" class="img-icon">
                    <h5 class="pt-30 pb-25 tran3s title"><?php echo esc_html($post_data[$i]['title']) ?></h5>
                    <div class="tran3s">
                        <?php echo esc_html(wp_trim_words( ($post_data[$i]['excerpt']), 15,'' )) ?>
                    </div>
                    <a href="<?php echo esc_url($post_data[$i]['permalink']) ?>" class="read-more tran3s"><i class="flaticon-next-1"></i></a>
                </div> <!-- /.feature-block-one -->
            <?php
            endfor;
            ?>
        </div>

        <div class="col-lg-4 col-md-6">
            <?php
            for($i=3; $i<5;$i++):
                ?>
                <div class="feature-block-one mb-45 md-mt-40">
                    <img src="<?php echo esc_url($post_data[$i]['thumbnail']) ?>" alt="" class="img-icon">
                    <h5 class="pt-30 pb-25 tran3s title"><?php echo esc_html($post_data[$i]['title']) ?></h5>
                    <div class="tran3s">
                        <?php echo esc_html(wp_trim_words( ($post_data[$i]['excerpt']), 15,'' )) ?>
                    </div>
                    <a href="<?php echo esc_url($post_data[$i]['permalink']) ?>" class="read-more tran3s"><i class="flaticon-next-1"></i></a>
                </div> <!-- /.feature-block-one -->
            <?php
            endfor;
            ?>
        </div>
    </div>
<?php
endif;