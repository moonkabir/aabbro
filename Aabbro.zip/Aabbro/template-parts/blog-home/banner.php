<?php

$aabbro_fp = new WP_Query(
    array(
        'meta_key' => 'banner',
        'meta_value' => '1',
        'posts_per_page' => 1,
    )
);

$post_data = array();
while ($aabbro_fp->have_posts()) {
    $aabbro_fp->the_post();
    $categories = get_the_category();
    $post_data[] = array(
        "title" => get_the_title(),
        "permalink" => get_permalink(),
        "thumbnail" => get_the_post_thumbnail_url(get_the_ID(), "large"),
        'excerpt' => get_the_excerpt(),
    );
}

?>
<div id="theme-banner-one">
    <?php while ($aabbro_fp->have_posts()):
        $aabbro_fp->the_post();
        ?>
        <div class="illustration wow zoomIn animated" data-wow-delay="1s" data-wow-duration="2s">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/banner-shape1.svg" alt="">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/banner-shape2.svg" alt=""
                 class="shape-one wow fadeInDown animated" data-wow-delay="1.8s">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/banner-shape3.svg" alt=""
                 class="shape-two wow fadeInUp animated" data-wow-delay="2.7s">
        </div>
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/oval-1.svg" alt="" class="oval-one">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-1.svg" alt="" class="shape-three">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-55.svg" alt="" class="shape-four">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-56.svg" alt="" class="shape-five">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-57.svg" alt="" class="shape-six">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-58.svg" alt="" class="shape-seven">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-59.svg" alt="" class="shape-eight">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-60.svg" alt="" class="shape-nine">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-61.svg" alt="" class="shape-ten">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-62.svg" alt="" class="shape-eleven">
        <div class="container">
            <div class="main-wrapper">
                <div class="slogan wow fadeInDown animated" data-wow-delay="0.2s"><span>70% Off</span> for first 3 months
                </div>
                <h1 class="main-title wow fadeInUp animated" data-wow-delay="0.4s">
                    <?php echo str_replace(' \n ', '<br>', __(get_the_title())); ?>
                </h1>
                <div class="sub-title wow fadeInUp animated" data-wow-delay="0.9s">
                    <?php
                    echo (str_replace('\n', '<br>', __(get_the_excerpt())));
                    ?>
                </div>
                <ul class="button-group lightgallery">
                    <li><a href="about-us-standard.html" class="more-button solid-button-one wow fadeInLeft animated"
                           data-wow-delay="1.5s">More About us <i class="fa fa-angle-right icon-right"
                                                                  aria-hidden="true"></i></a></li>

                    <li><a data-fancybox href="https://www.youtube.com/embed/aXFSJTjVjw0"
                           class="fancybox video-button-one wow fadeInRight animated" data-wow-delay="1.5s">See live demo.
                            <i class="flaticon-play-button icon-right"></i></a></li>
                </ul>
            </div> <!-- /.main-wrapper -->
        </div> <!-- /.container -->
    <?php endwhile;?>
</div> <!-- /#theme-banner-one -->