<?php
$philosophy_fp = new WP_Query(
    array(
        'meta_key'       => 'blog',
        'meta_value'     => '1',
        'posts_per_page' => 4
    )
);

$post_data = array();
while ( $philosophy_fp->have_posts() ) {
    $philosophy_fp->the_post();
    $post_data[] = array(
        "title" => get_the_title(),
        "permalink"=>get_permalink(),
        "date"=>get_the_date(),
        'excerpt'=>get_the_excerpt(),
        "thumbnail"=>get_the_post_thumbnail_url(get_the_ID(),"large"),
        "author"=>get_the_author_meta("display_name")
    );
}
if ( $philosophy_fp->post_count > 1 ):
    ?>

    <div class="blog-one-slider">
        <?php
            for($i=1; $i<4;$i++):
        ?>
        <div class="item">
            <div class="single-blog-post">
                <div class="flip-box-front">
                    <div class="clearfix">
                        <img src="<?php echo esc_url($post_data[$i]['thumbnail']) ?>" alt="" class="author-img">
                        <div class="author-info">
                            <h6 class="name"><?php echo esc_html($post_data[$i]['author']) ?></h6>
                            <div class="date"><?php echo esc_html($post_data[$i]['date']) ?></div>
                        </div>
                    </div>
                    <a href="<?php echo esc_url($post_data[$i]['permalink']) ?>" class="title"><?php echo esc_html($post_data[$i]['title']) ?></a>
                    <p><?php echo esc_html(wp_trim_words( ($post_data[$i]['excerpt']), 17,'..' )) ?></p>
                </div> <!-- /.flip-box-front -->
                <div class="flip-box-back">
                    <div class="author-info">
                        <h6 class="name"><?php echo esc_html($post_data[$i]['author']) ?></h6>
                        <div class="date"><?php echo esc_html($post_data[$i]['date']) ?></div>
                    </div>
                    <a href="<?php echo esc_url($post_data[$i]['permalink']) ?>" class="title"><?php echo esc_html($post_data[$i]['title']) ?></a>
                    <a href="<?php echo esc_url($post_data[$i]['permalink']) ?>" class="more"><i class='flaticon-next-1'></i></a>
                </div> <!-- /.flip-box-back -->
            </div> <!-- /.single-blog-post -->
        </div>
        <?php
            endfor;
        ?>
    </div>

<?php
endif;
