<?php
$aabbro_fp = new WP_Query(
    array(
        'meta_key'       => 'recentwork',
        'meta_value'     => '1',
        'posts_per_page' => 4
    )
);

$post_data = array();
while ( $aabbro_fp->have_posts() ) {
    $aabbro_fp->the_post();
    $post_data[] = array(
        "permalink"=>get_permalink(),
        "thumbnail"=>get_the_post_thumbnail_url(get_the_ID(),"large")
    );
}

if ( $aabbro_fp->post_count > 1 ):
    ?>
    <div class="gallery-slider lightgallery">
    <?php
    for($i=1; $i<4;$i++):
        ?>
        <div class="item">
            <div class="img-box">
                <img src="<?php echo esc_url($post_data[$i]['thumbnail']) ?>" alt="">
                <div class="hover-content">
                    <a href="<?php echo esc_url($post_data[$i]['permalink']) ?>" class="icon zoom fancybox" data-fancybox="images" data-caption="My caption">+</a>
                </div>
            </div>
        </div>
    <?php
    endfor;
    ?>
    </div> <!-- /.gallery-slider -->
<?php
endif;