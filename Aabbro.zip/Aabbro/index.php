<?php get_header();?>


    <!--
                =============================================
                    Theme Main Banner One
                ==============================================
                -->
<?php if (have_posts()):
    the_post();
    ?>
    <?php get_template_part("template-parts/blog-home/banner");?>
<?php
endif;
?>




    <!--
    =============================================
        Our Service One
    ==============================================
    -->
    <div class="our-service-one pos-r md-pt-140 md-pb-20 m0">
        <div class="container">
            <div class="inner-wrapper pos-r">
                <div class="theme-title-one">
                    <h2 class="main-title underline"><span>Let’s check our</span><br> <span>services.</span></h2>
                </div> <!-- /.theme-title-one -->
                    <?php get_template_part("template-parts/blog-home/featured"); ?>
            </div>
        </div> <!-- /.container -->
    </div> <!-- /.our-service-one -->



    <!--
    =============================================
        Theme Counter
    ==============================================
    -->
    <div class="agn-counter-section">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-55.svg" alt="" class="shape-one">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-59.svg" alt="" class="shape-two">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-61.svg" alt="" class="shape-three">
        <div class="container">
            <div class="main-wrapper">
                <div class="theme-title-one text-center">
                    <h2 class="main-title">We completed 1500+ Projects Yearly <br>Successfully & counting</h2>
                </div> <!-- /.theme-title-one -->

                <div class="counter-wrapper">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="single-counter-box">
                                <h2 class="number"><span class="timer" data-from="0" data-to="16" data-speed="1200" data-refresh-interval="5">0</span>k</h2>
                                <p>Global Customer</p>
                            </div> <!-- /.single-counter-box -->
                        </div>
                        <div class="col-sm-4">
                            <div class="single-counter-box">
                                <h2 class="number"><span class="timer" data-from="0" data-to="500" data-speed="1200" data-refresh-interval="5">0</span>+</h2>
                                <p>Completed Projects</p>
                            </div> <!-- /.single-counter-box -->
                        </div>
                        <div class="col-sm-4">
                            <div class="single-counter-box">
                                <h2 class="number"><span class="timer" data-from="0" data-to="460" data-speed="1200" data-refresh-interval="5">0</span>+</h2>
                                <p>Experts Worker</p>
                            </div> <!-- /.single-counter-box -->
                        </div>
                    </div>
                </div> <!-- /.counter-wrapper -->
            </div> <!-- /.main-wrapper -->
        </div> <!-- /.container -->
    </div> <!-- /.agn-counter-section -->



    <!--
    =============================================
        Our Gallery
    ==============================================
    -->
    <div class="agn-our-gallery">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-62.svg" alt="" class="shape-one">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-55.svg" alt="" class="shape-two">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-61.svg" alt="" class="shape-three">
        <div class="container">
            <div class="theme-title-one">
                <h2 class="main-title"><?php _e("Check some of our <br>Recent work.","aabbro") ?> </h2>
                <p class="bottom-title"><?php _e("Click the below button to check all of our work.","aabbro") ?> </p>
            </div> <!-- /.theme-title-one -->
        </div> <!-- /.container -->
        <div class="main-wrapper">
            <a href="product-full-width.html" class="view-gallery">View Gallery</a>
            <?php get_template_part("template-parts/blog-home/recentwork"); ?>
        </div> <!-- /.main-wrapper -->
    </div> <!-- /.agn-our-gallery -->


			<!--
			=====================================================
				Testimonial
			=====================================================
			-->
			<div class="agn-testimonial">
                <?php get_template_part("template-parts/blog-home/testimonial"); ?>
			</div> <!-- /.agn-testimonial -->
			<!--
			=====================================================
				Our Blog
			=====================================================
			-->
			<div class="agn-home-blog our-blog-one">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-58.svg" alt="" class="shape-one">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-57.svg" alt="" class="shape-two">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-9.svg" alt="" class="shape-three">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-55.svg" alt="" class="shape-four">
				<div class="container">
					<div class="theme-title-one text-center">
						<div class="upper-title">Our Blog</div>
						<h2 class="main-title">Our Company News</h2>
					</div> <!-- /.theme-title-one -->

                    <?php get_template_part("template-parts/blog-home/blog"); ?>

				</div>
			</div> <!-- /.our-blog-one -->



			<!-- 
			=============================================
				Contact Banner
			============================================== 
			-->
			<div class="agn-contact-banner">
				<div class="container">
					<h2 class="title">Do you have any projects? <br>Contact us.</h2>
					<a href="contact-us-agency.html" class="contact-button line-button-one">Contact Us</a>
				</div> <!-- /.contianer -->
			</div> <!-- /.agn-contact-banner -->


<?php get_footer();?>