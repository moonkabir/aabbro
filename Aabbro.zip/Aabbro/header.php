<!DOCTYPE html>
<html lang="<?php language_attributes();?>">

<head>
    <meta charset="<?php bloginfo('charset');?>">
    <meta name="keywords" content="Digital marketing agency, Digital marketing company, Digital marketing services">
    <meta name="author" content="creativegigs">

    <!-- For IE -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- For Resposive Device -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- For Window Tab Color -->
    <!-- Chrome, Firefox OS and Opera -->
    <meta name="theme-color" content="#233D63">
    <!-- Windows Phone -->
    <meta name="msapplication-navbutton-color" content="#233D63">
    <!-- iOS Safari -->
    <meta name="apple-mobile-web-app-status-bar-style" content="#233D63">
    <!-- <title>Rogan - Creative Multi-Purpose HTML Template</title> -->


    <!-- Fix Internet Explorer ______________________________________-->
    <!--[if lt IE 9]>
			<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
			<script src="vendor/html5shiv.js"></script>
			<script src="vendor/respond.js"></script>
        <![endif]-->
    <?php wp_head();?>
</head>

<body <?php body_class();?>>
    <div class="main-page-wrapper">

        <!-- ===================================================
				Loading Transition
			==================================================== -->
        <!-- Preloader -->
        <!-- <section>
            <div id="preloader">
                <div id="ctn-preloader" class="ctn-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                            <span data-text-preloader="R" class="letters-loading">
                                R
                            </span>
                            <span data-text-preloader="O" class="letters-loading">
                                O
                            </span>
                            <span data-text-preloader="G" class="letters-loading">
                                G
                            </span>
                            <span data-text-preloader="A" class="letters-loading">
                                A
                            </span>
                            <span data-text-preloader="N" class="letters-loading">
                                N
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->


        <!--
			=============================================
				Theme Main Menu
			==============================================
			-->
        <div class="theme-main-menu theme-menu-one">
            <div class="logo">
                <!-- <a href="index.html"><img src="/assets/images/logo/logo.svg" alt=""></a> -->
                <?php if (has_custom_logo()): $logo_url = wp_get_attachment_image_src(get_theme_mod('custom_logo'), 'full');?>
                <a href="<?php echo esc_url(home_url('/')); ?>" class="logo logo-fixed"><img
                        src="<?php echo esc_url($logo_url[0]); ?>" alt="aabbro" class="logo-img"></a>
                <?php endif;?>
            </div>
            <!-- <nav id="mega-menu-holder" class="navbar navbar-expand-lg">
                <div class="container nav-container">
                    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <i class="flaticon-setup"></i>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav">
                            <li class="nav-item active dropdown">
                                <a href="index.html" class="nav-link dropdown-toggle" data-toggle="dropdown">Home.</a>

                            </li>
                            <li class="nav-item dropdown position-relative">
                                <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Pages.</a>


                            </li>
                            <li class="nav-item dropdown position-relative">
                                <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">Features.</a>

                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">elements.</a>

                            </li>
                            <li class="nav-item dropdown position-relative">
                                <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown">News.</a>

                            </li>
                        </ul>
                    </div>
                </div> /.container
            </nav> /#mega-menu-holder -->
            <?php
if (has_nav_menu('main-menu')):
 echo str_replace('<li class="', '<li class="nav-item ',
  wp_nav_menu(array(
   'theme_location' => 'main-menu',
   'menu' => '',
   'container' => 'nav',
   'container_class' => 'navbar navbar-expand-lg',
   'container_id' => 'mega-menu-holder',
   'menu_class' => 'navbar-nav',
   'menu_id' => '',
   'echo' => true,
   'before' => '',
   'after' => '',
   'link_before' => '',
   'link_after' => '',
   'items_wrap' => '<div class="container nav-container"><button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
																										                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
																										                    aria-expanded="false" aria-label="Toggle navigation">
																										                    <i class="flaticon-setup"></i>
																										                </button>
																										                <div class="collapse navbar-collapse" id="navbarSupportedContent"><ul id = "%1$s" class = "%2$s">%3$s</ul></div></div>',
   'walker' => new Aabbro_Walker_Nav_Menu(),
  )
  ));
endif;

?>
            <div class="header-right-widget">
                <ul>
                    <li class="call-us">Call Us <a href="#">+880.762.009</a></li>
                    <li class="language-switcher">
                        <div class="dropdown">
                            <button type="button" class="dropdown-toggle" data-toggle="dropdown">
                                En
                            </button>
                            <div class="dropdown-menu dropdown-menu-right">
                                <ul class="ct-language__dropdown">
                                    <li><a href="#googtrans(en|en)" class="lang-en lang-select active"
                                            data-lang="en">USA</a>
                                    </li>
                                    <li><a href="#googtrans(en|es)" class="lang-es lang-select"
                                            data-lang="es">MEXICO</a></li>
                                    <li><a href="#googtrans(en|fr)" class="lang-es lang-select"
                                            data-lang="fr">FRANCE</a></li>
                                    <li><a href="#googtrans(en|zh-CN)" class="lang-es lang-select"
                                            data-lang="zh-CN">CHINA</a>
                                    </li>
                                    <li><a href="#googtrans(en|de)" class="lang-es lang-select"
                                            data-lang="de">German</a></li>
                                    <!-- <li><a href="#googtrans(en|hi)" class="lang-es lang-select" data-lang="hi">Hindi</a>
                                    </li> -->
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li><a href="contact-us-standard.html" class="contact-us white-shdw-button">Contact Us <i
                                class="icon flaticon-next"></i></a></li>
                </ul>
            </div> <!-- /.header-right-widget -->
        </div> <!-- /.theme-main-menu -->