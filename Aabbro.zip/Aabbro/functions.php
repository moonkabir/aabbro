<?php
if (!defined('ABSPATH')) {
 exit; // Exit if accessed directly.
}
require_once (get_theme_file_path("inc/tgm.php"));

$aabbro_includes = array(
 'theme-setup.php', // Initialize theme default settings.
 'enqueue.php',
 'aabbro_walker_nav_menu.php',
);
foreach ($aabbro_includes as $file) {
 $filepath = locate_template('inc/' . $file);
 if (!$filepath) {
  trigger_error(sprintf('Error locating /inc%s for inclusion', $file), E_USER_ERROR);
 }
 require_once $filepath;
}

function wpdocs_excerpt_more( $more ) {
    return ' ';
}
add_filter( 'excerpt_more', 'wpdocs_excerpt_more' );

function aabbro_widgets_init() {
    register_sidebar( array(
        'name' => __( 'footer widget', 'aabbro' ),
        'id' => 'footer-1',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'mypro' ),
        'before_widget' => '',
        'after_widget'  => '',
        'before_title'  => '<h2 class="widgettitle">',
        'after_title'   => '</h2>',
    ) );
    register_sidebar( array(
        'name' => __( 'footer service', 'aabbro' ),
        'id' => 'footer-2',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'mypro' ),
        'before_widget' => '',
        'after_widget'  => '',
        'before_title'  => '<h5 class="title">',
        'after_title'   => '</h5>',
    ) );
    register_sidebar( array(
        'name' => __( 'footer about', 'aabbro' ),
        'id' => 'footer-3',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'mypro' ),
        'before_widget' => '',
        'after_widget'  => '',
        'before_title'  => '<h5 class="title">',
        'after_title'   => '</h5>',
    ) );
    register_sidebar( array(
        'name' => __( 'footer address', 'aabbro' ),
        'id' => 'footer-4',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'mypro' ),
        'before_widget' => '',
        'after_widget'  => '',
        'before_title'  => '<h5 class="title">',
        'after_title'   => '</h5>',
    ) );
}
add_action( 'widgets_init', 'aabbro_widgets_init' );