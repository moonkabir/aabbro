			<!--
			=====================================================
				Footer
			=====================================================
			-->
			<footer class="theme-footer-one">
			    <div class="shape-one" data-aos="zoom-in-right"></div>
			    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/shape/shape-67.svg" alt="" class="shape-two">
			    <div class="top-footer">
			        <div class="container">
                        <div class="row">
                            <div class="col-lg-3 col-sm-6 col-12 about-widget" data-aos="fade-up">
                                <form class="custom-contact" method="post">
                                    <?php
                                    if(is_active_sidebar("footer-1")){
                                        dynamic_sidebar("footer-1");
                                    }
                                    ?>
                                </form>
                                <!-- <a href="#" class="email">boga.inc@company.com</a>
                                <a href="#" class="phone">720.661.2231</a> -->
                            </div> <!-- /.about-widget -->
                            <div class="col-lg-3 col-lg-3 col-sm-6 col-12 footer-list" data-aos="fade-up">
                                <?php
                                if(is_active_sidebar("footer-2")){
                                    dynamic_sidebar("footer-2");
                                }
                                ?>
                            </div> <!-- /.footer-recent-post -->
                            <div class="col-lg-3 col-sm-6 col-12 footer-list" data-aos="fade-up">
                                <?php
                                if(is_active_sidebar("footer-3")){
                                    dynamic_sidebar("footer-3");
                                }
                                ?>
                            </div> <!-- /.footer-list -->
                            <div class="col-lg-3 col-lg-2 col-sm-6 col-12 footer-information" data-aos="fade-up">
                                <?php
                                if(is_active_sidebar("footer-4")){
                                    dynamic_sidebar("footer-4");
                                }
                                ?>
                            </div>
                        </div> <!-- /.row -->
			        </div> <!-- /.container -->
			    </div> <!-- /.top-footer -->

			    <div class="container">
			        <div class="bottom-footer">
			            <div class="clearfix">
			                <p>&copy; 2019 copyright all right reserved</p>
			                <ul>
			                    <li><a href="#">Privace & Policy.</a></li>
			                    <li><a href="faq.html">Faq.</a></li>
			                    <li><a href="#">Terms.</a></li>
			                </ul>
			            </div>
			        </div> <!-- /.bottom-footer -->
			    </div>
			</footer> <!-- /.theme-footer-one -->




			<!-- Scroll Top Button -->
			<button class="scroll-top tran3s">
			    <i class="fa fa-angle-up" aria-hidden="true"></i>
			</button>




			</div> <!-- /.main-page-wrapper -->
			<?php wp_footer();?>
			</body>

			</html>